package com.senac.sistemacoleta.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senac.sistemacoleta.entity.Descarte;
import com.senac.sistemacoleta.service.DescarteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.*;



@RestController
@RequestMapping("/descartes")
public class DescarteController {

	@Autowired
	private DescarteService service;
	
	@Operation(summary = "Listar todos os descartes", description = "Retorna uma lista de todos os descartes registrados")
	@ApiResponse(responseCode = "200", description = "Operação bem-sucedida", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descarte.class)))
	@GetMapping("/list")
	public ResponseEntity<List<Descarte>> findAll(){
		List<Descarte> descartes = service.listAll();
		return ResponseEntity.ok(descartes);
	}
	@Operation(summary = "Buscar descarte por ID", description = "Retorna um descarte específico pelo seu ID")
	@ApiResponse(responseCode = "200", description = "Descarte encontrado", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descarte.class)))
	@ApiResponse(responseCode = "404", description = "Descarte não encontrado")
	@GetMapping("/{id}")
	public ResponseEntity<Descarte> getDescarte(@PathVariable Long id) {
	    Optional<Descarte> descarte = service.findById(id);
	    if(descarte.isPresent()) {
	    	return ResponseEntity.ok(descarte.get());
	    } else {
	    	return ResponseEntity.notFound().build();
	    }
	}
	@Operation(summary = "Inserir um novo descarte", description = "Cria um novo registro de descarte")
	@ApiResponse(responseCode = "200", description = "Descarte criado com sucesso", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descarte.class)))
	@ApiResponse(responseCode = "500", description = "Erro interno no servidor")
	@PostMapping
	public ResponseEntity<Descarte> insert(@RequestBody Descarte newDescarte) {
		Descarte descarte = service.save(newDescarte);
		if(descarte != null) {
			return ResponseEntity.ok(descarte);
		} else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	@Operation(summary = "Atualizar um descarte", description = "Atualiza os dados de um descarte existente")
	@ApiResponse(responseCode = "200", description = "Descarte atualizado com sucesso", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descarte.class)))
	@ApiResponse(responseCode = "404", description = "Descarte não encontrado")
	@PutMapping("/{id}")
	public ResponseEntity<Descarte> replace(@RequestBody Descarte newDescarte, @PathVariable Long id) {
		Descarte descarte = service.update(newDescarte, id);
		return descarte != null ? ResponseEntity.ok(descarte) : ResponseEntity.notFound().build();
	}
	@Operation(summary = "Deletar um descarte", description = "Remove um descarte pelo seu ID")
	@ApiResponse(responseCode = "204", description = "Descarte deletado com sucesso")
	@ApiResponse(responseCode = "404", description = "Descarte não encontrado")
	@DeleteMapping("/{id}")
	public ResponseEntity<Descarte> delete(@PathVariable Long id) {
		Boolean resp = service.delete(id);
		if(resp) {
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}
