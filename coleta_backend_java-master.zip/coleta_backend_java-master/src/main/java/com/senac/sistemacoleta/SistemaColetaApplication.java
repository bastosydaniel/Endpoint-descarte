package com.senac.sistemacoleta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaColetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaColetaApplication.class, args);
	}

}
